﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project
{
    public partial class Form1 : Form
    {
        Random rng = new Random();
        Player megaMan;
        Boss currentBoss;
        Explosion boom;
        List<Boss> bossList = new List<Boss>();
        List<Bullet> shotsFired = new List<Bullet>();
        List<Explosion> explodeList = new List<Explosion>();


        public enum KeyMove { none, up, down, forward, shoot }
        public int formWidth;
        public int formHeight;

        KeyMove leftKey = KeyMove.none;
        KeyMove shotKey = KeyMove.none;

        public Form1()
        {
            InitializeComponent();
            formWidth = ClientSize.Width;
            formHeight = ClientSize.Height;
            megaMan = new Player(this, 15, 300);
            //Explosion pop = new Explosion(this, currentBoss.X, currentBoss.Y, Environment.CurrentDirectory + "/Explosion");
            Boss robotMaster = new Boss(this, 1000, 300, Environment.CurrentDirectory + "/drill");
            Boss robotMaster2 = new Boss(this, 1000, 250, Environment.CurrentDirectory + "/quick");
            Boss robotMaster3 = new Boss(this, 1000, 50, Environment.CurrentDirectory + "/snake");
            Boss robotMaster4 = new Boss(this, 1000, 150, Environment.CurrentDirectory + "/skull");
            bossList.Add(robotMaster);
            bossList.Add(robotMaster2);
            bossList.Add(robotMaster3);
            bossList.Add(robotMaster4);
            NewBoss();

        }
        public void NewBoss()
        {
            Boss tmp = bossList[rng.Next(0, bossList.Count)];
            this.Controls.Add(tmp.bossPic);
            currentBoss = tmp;
        }


        private void tmrMain_Tick(object sender, EventArgs e)
        {
            this.Invalidate(false);
            if (leftKey == KeyMove.up)
                megaMan.MoveUpDown(true);
            if (leftKey == KeyMove.down)
                megaMan.MoveUpDown(false);
            if (leftKey == KeyMove.forward)
                currentBoss.Running(true);
            if (leftKey == KeyMove.forward && shotKey != KeyMove.shoot)
                megaMan.Running(true, false);
            if (leftKey == KeyMove.forward && shotKey == KeyMove.shoot)
                megaMan.Running(true, true);
            if (leftKey == KeyMove.none)
            {
                megaMan.Running(false, false);
                currentBoss.Running(false);
            }
            if (leftKey == KeyMove.none && shotKey == KeyMove.shoot)
                megaMan.Running(false, true);


            for (int i = 0; i < shotsFired.Count; i++)
            {
                if (CrashTest(currentBoss, shotsFired[i]))
                {
                    currentBoss.Damaged(true);
                    if (currentBoss.Health == 0)
                    {
                        Destroyed();                            //Calls the explosions
                        currentBoss.Pop();                      //Removes boss and places a new one
                        bossList.Remove(currentBoss);
                        if (bossList.Count == 0)
                            this.Close();                        //Current "beating" the game
                        else
                            NewBoss();                           //Get a new boss from the list
                    }
                    shotsFired[i].Gone();
                    shotsFired.RemoveAt(i);
                }
                if (shotsFired.Count != 0)
                    if (shotsFired[i].X + shotsFired[i].Width > this.ClientSize.Width)
                        shotsFired.RemoveAt(i);
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up) leftKey = KeyMove.up;
            if (e.KeyCode == Keys.Down) leftKey = KeyMove.down;
            if (e.KeyCode == Keys.Right) leftKey = KeyMove.forward;

            if (e.KeyCode == Keys.Space)
            {
                shotKey = KeyMove.shoot;
                if (shotsFired.Count < 3)
                    shotsFired.Add(new Bullet(this, megaMan.X + (megaMan.Width - 5), megaMan.Y + 22));
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up) leftKey = KeyMove.none;
            if (e.KeyCode == Keys.Down) leftKey = KeyMove.none;
            if (e.KeyCode == Keys.Right) leftKey = KeyMove.none;
            if (e.KeyCode == Keys.Space) shotKey = KeyMove.none;
        }

        private bool CrashTest(Boss boss, Bullet bullet)
        {
            if (boss.X > bullet.X + bullet.Width)
                return false;
            if (bullet.X + bullet.Width < boss.X)
                return false;
            if (boss.Y + boss.Height < bullet.Y)
                return false;
            if (bullet.Y + bullet.Height < boss.Y)
                return false;

            return true;
        }

        private bool OffScreen(Explosion bomb)
        {
            if (bomb.X < formWidth)
                return false;
            if (bomb.X > 0)
                return false;
            if (bomb.Y > 0)
                return false;
            if (bomb.Y < formHeight)
                return false;

            return true;

        }

        private void Destroyed()        // This creates all 16 explosion entities
        {                               // Super ugly, would like to use a loop, unsure how
            explodeList.Add(new Explosion(this, (currentBoss.X + currentBoss.Width / 2), (currentBoss.Y + currentBoss.Height / 2), Environment.CurrentDirectory + "/Explosion", 0, -5));
            explodeList.Add(new Explosion(this, (currentBoss.X + currentBoss.Width / 2), (currentBoss.Y + currentBoss.Height / 2), Environment.CurrentDirectory + "/Explosion", 5, -5));
            explodeList.Add(new Explosion(this, (currentBoss.X + currentBoss.Width / 2), (currentBoss.Y + currentBoss.Height / 2), Environment.CurrentDirectory + "/Explosion", 5, 0));
            explodeList.Add(new Explosion(this, (currentBoss.X + currentBoss.Width / 2), (currentBoss.Y + currentBoss.Height / 2), Environment.CurrentDirectory + "/Explosion", 5, 5));
            explodeList.Add(new Explosion(this, (currentBoss.X + currentBoss.Width / 2), (currentBoss.Y + currentBoss.Height / 2), Environment.CurrentDirectory + "/Explosion", 0, 5));
            explodeList.Add(new Explosion(this, (currentBoss.X + currentBoss.Width / 2), (currentBoss.Y + currentBoss.Height / 2), Environment.CurrentDirectory + "/Explosion", -5, 0));
            explodeList.Add(new Explosion(this, (currentBoss.X + currentBoss.Width / 2), (currentBoss.Y + currentBoss.Height / 2), Environment.CurrentDirectory + "/Explosion", -5, 5));
            explodeList.Add(new Explosion(this, (currentBoss.X + currentBoss.Width / 2), (currentBoss.Y + currentBoss.Height / 2), Environment.CurrentDirectory + "/Explosion", -5, -5));
            explodeList.Add(new Explosion(this, (currentBoss.X + currentBoss.Width / 2), (currentBoss.Y + currentBoss.Height / 2), Environment.CurrentDirectory + "/Explosion", 0, -8));
            explodeList.Add(new Explosion(this, (currentBoss.X + currentBoss.Width / 2), (currentBoss.Y + currentBoss.Height / 2), Environment.CurrentDirectory + "/Explosion", 8, -8));
            explodeList.Add(new Explosion(this, (currentBoss.X + currentBoss.Width / 2), (currentBoss.Y + currentBoss.Height / 2), Environment.CurrentDirectory + "/Explosion", 8, 0));
            explodeList.Add(new Explosion(this, (currentBoss.X + currentBoss.Width / 2), (currentBoss.Y + currentBoss.Height / 2), Environment.CurrentDirectory + "/Explosion", 8, 8));
            explodeList.Add(new Explosion(this, (currentBoss.X + currentBoss.Width / 2), (currentBoss.Y + currentBoss.Height / 2), Environment.CurrentDirectory + "/Explosion", 0, 8));
            explodeList.Add(new Explosion(this, (currentBoss.X + currentBoss.Width / 2), (currentBoss.Y + currentBoss.Height / 2), Environment.CurrentDirectory + "/Explosion", -8, 0));
            explodeList.Add(new Explosion(this, (currentBoss.X + currentBoss.Width / 2), (currentBoss.Y + currentBoss.Height / 2), Environment.CurrentDirectory + "/Explosion", -8, 8));
            explodeList.Add(new Explosion(this, (currentBoss.X + currentBoss.Width / 2), (currentBoss.Y + currentBoss.Height / 2), Environment.CurrentDirectory + "/Explosion", -8, -8));
            for (int i = 0; i < explodeList.Count; i++)
            {
                if (!OffScreen(explodeList[i]))
                {
                    explodeList[i].Gone();
                    explodeList.RemoveAt(i);
                }
            }

        }
    }
}
